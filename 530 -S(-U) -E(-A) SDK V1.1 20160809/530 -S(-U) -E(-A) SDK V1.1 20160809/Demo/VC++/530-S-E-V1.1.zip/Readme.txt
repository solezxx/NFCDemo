[20160729]
1. maybe missing some mfc library(dll), please copy the missing library(dll) from the "Tool/Missing DLL" directory 
   or install the packet "vcredist_x86_2010.exe"
2. 32Bit directory contain the 32 bit demo for 14443A(S50/S70), 14443B, 15693 card
3. 64Bit directory contain the 64 bit demo for 14443A(S50/S70), 14443B, 15693 card
4. Ultralight directory contain the 32 bit demo for ultralight card
 